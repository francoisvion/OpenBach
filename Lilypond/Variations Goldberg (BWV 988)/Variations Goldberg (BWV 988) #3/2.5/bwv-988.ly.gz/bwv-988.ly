\version "2.18.2" 

\paper {
%	annotate-spacing = ##t
	print-page-number = ##t
	print-first-page-number = ##t
	first-page-number = #5

	#(set-paper-size "arch a")

        top-margin = 12 \mm
        bottom-margin = 12 \mm
        left-margin = 18 \mm
        right-margin = 18 \mm

	ragged-last-bottom = ##f
	ragged-bottom = ##f
	oddFooterMarkup = \markup \column { \null \null \fromproperty #'header:copyright      }
}

\pointAndClickOff
%\pointAndClickOn

#(set-global-staff-size 19)

H = \once \override NoteHead.style = #'harmonic-black
T = \once \override NoteHead.style = #'harmonic

extendLV = #(define-music-function (parser location further) (number?)
#{
        \once \override LaissezVibrerTie #'X-extent = #'(0 . 0)
        \once \override LaissezVibrerTie #'details #'note-head-gap = #(/ further -2.1)
        \once \override LaissezVibrerTie #'extra-offset = #(cons (/ further 2) 0)
#})

graceSchleifer = 
#(define-music-function (parser location note) (ly:music?)
  (make-music 'SequentialMusic
   'elements (list #{
              \once \override Voice.NoteHead #'stencil = #ly:text-interface::print
              \once \override Voice.NoteHead #'X-extent = #'(-2 . -0)
              \once \override Voice.NoteHead #'text =
              #(markup #:large #:halign 0.4 #:raise 0.0 #:combine #:halign 1.1 #:musicglyph "scripts.prall"
              #:rotate 120 #:normalsize #:raise 2.4 #:musicglyph "flags.u3")
              \once \override Flag #'style = #'no-flag 
              \once \override Voice.Stem #'stencil = ##f #}
              note)))

GraceSchleifer = 
#(define-music-function (parser location note) (ly:music?)
  (make-music 'SequentialMusic
   'elements (list #{
              \once \override Voice.NoteHead #'stencil = #ly:text-interface::print
              \once \override Voice.NoteHead #'X-extent = #'(-2 . -0)
              \once \override Voice.NoteHead #'text =
              #(markup #:large #:halign 0.4 #:raise 1.0 #:combine #:halign 1.1 #:musicglyph "scripts.prall"
              #:rotate 120 #:normalsize #:raise 2.4 #:musicglyph "flags.u3")
              \once \override Flag #'style = #'no-flag 
              \once \override Voice.Stem #'stencil = ##f #}
              note)))

TIn =  \shape #'((0.8 . 0.0)(0.0 . 0.0)(0.0 . 0.0)(-0.8 . 0.0)) Tie
TIna = \shape #'((0.8 . 0.0)(0.0 . 0.0)(0.0 . 0.0)(0.0 . 0.0)) Tie
TInb = \shape #'((0.4 . 0.0)(0.0 . 0.0)(0.0 . 0.0)(-0.4 . 0.0)) Tie
TInbb = \shape #'((0.4 . 0.0)(0.0 . 0.0)(0.0 . 0.0)(-0.4 . 0.0)) Tie
TInc = \shape #'((0.6 . 0.3)(0.0 . 0.4)(0.0 . 0.4)(-0.1 . 0.3)) Tie
TInd = \shape #'((0.3 . 0.0)(0.0 . 0.0)(0.0 . 0.0)(-0.3 . 0.0)) Tie
TIne = \shape #'((0.6 . 0.0)(0.0 . 0.0)(0.0 . 0.0)(-0.6 . 0.0)) Tie
TInf = \shape #'((0.6 . 0.0)(0.0 . 0.0)(0.0 . 0.0)(-0.4 . 0.0)) Tie
TIng = \shape #'((0.6 . 0.0)(0.0 . 0.0)(0.0 . 0.0)(-0.2 . 0.0)) Tie
TInh = \shape #'((0.4 . 0.0)(0.0 . -0.1)(0.0 . -0.1)(-0.4 . -0.0)) Tie
TIni = \shape #'((0.4 . 0.0)(0.0 . 0.1)(0.0 . 0.1)(-0.4 . 0.0)) Tie
TInj = \shape #'((0.3 . 0.0)(0.0 . -0.1)(0.0 . -0.1)(-0.3 . 0.0)) Tie
TInk = \shape #'((0.6 . 0.0)(0.0 . -0.1)(0.0 . -0.1)(-0.6 . -0.0)) Tie
TInl = \shape #'((0.0 . 0.0)(0.0 . 0.0)(0.0 . 0.0)(-0.3 . 0.0)) Tie
TInm = \shape #'((0.4 . 0.1)(0.0 . 0.1)(0.0 . 0.1)(-0.4 . 0.1)) Tie
TInn = \shape #'((0.2 . 0.14)(0.0 . 0.0)(0.0 . 0.0)(-0.3 . 0.14)) Tie
Tr = \shape #'((0.4 . 0.0)(0.3 . 0.0)(0.0 . 0.0)(0.0 . 0.0)) Tie
Tl = \shape #'((0.0 . 0.0)(0.0 . 0.0)(0.0 . 0.0)(-0.2 . 0.0)) Tie
Tla = \shape #'((0.2 . 0.0)(0.0 . 0.0)(0.0 . 0.0)(-0.5 . 0.0)) Tie

TUp = \shape #'((0.0 . 0.4)(0.0 . 0.4)(0.0 . 0.4)(0.0 . 0.4)) Tie
TUpa = \shape #'((0.0 . 0.4)(0.0 . 0.6)(0.0 . 0.6)(0.0 . 0.4)) Tie
TUpaa = \shape #'((-0.3 . 0.5)(0.0 . 0.6)(0.0 . 0.6)(0.3 . 0.5)) Tie
TUpb = \shape #'((0.0 . 0.2)(0.0 . 0.2)(0.0 . 0.2)(0.0 . 0.2)) Tie
TUpc = \shape #'((0.0 . 0.1)(0.0 . 0.1)(0.0 . 0.1)(0.0 . 0.1)) Tie
TUpd = \shape #'((0.0 . 0.3)(0.0 . 0.6)(0.0 . 0.6)(0.0 . 0.3)) Tie
TUpe = \shape #'((0.0 . 0.2)(0.0 . -0.1)(0.0 . -0.1)(0.0 . 0.2)) Tie
TUpi = \shape #'((0.4 . 0.0)(0.0 . 0.0)(0.0 . 0.0)(-0.4 . 0.0)) Tie
TUpj = \shape #'((0.0 . 0.0)(0.0 . 0.1)(0.0 . 0.1)(0.0 . 0.0)) Tie
TUpk = \shape #'((0.2 . 0.1)(0.0 . -0.2)(0.0 . -0.2)(-0.2 . 0.1)) Tie
TUpo = \shape #'((-0.4 . 0.4)(0.0 . 0.4)(0.0 . 0.4)(0.4 . 0.4)) Tie
TUpp = \shape #'((-0.0 . 0.3)(0.0 . 0.0)(0.0 . 0.0)(0.0 . 0.3)) Tie
TUpq = \shape #'((0.0 . 0.4)(0.0 . 0.4)(0.0 . 0.4)(0.4 . 0.4)) Tie
TUpr = \shape #'((0.0 . 0.4)(0.0 . 0.4)(0.4 . 0.4)(0.8 . 0.4)) Tie
TUps = \shape #'((0.0 . 0.1)(0.0 . 0.0)(0.0 . 0.0)(-0.2 . 0.1)) Tie
TUpt = \shape #'((-0.3 . 0.5)(0.0 . 0.6)(0.0 . 0.6)(0.3 . 0.5)) Tie
TUpu = \shape #'((0.2 . 0.1)(0.0 . -0.1)(0.0 . -0.1)(-0.2 . 0.1)) Tie
TUpv = \shape #'((-0.1 . 0.4)(-0.4 . 0.7)(0.4 . 0.7)(0.2 . 0.4)) Tie


TDn = \shape #'((0.0 . -0.4)(0.0 . -0.4)(0.0 . -0.4)(0.0 . -0.4)) Tie
TDna = \shape #'((0.0 . -0.1)(0.0 . -0.1)(0.0 . -0.1)(-0.0 . -0.1)) Tie
TDnaa = \shape #'((0.0 . -0.3)(0.0 . -0.6)(0.0 . -0.6)(-0.0 . -0.3)) Tie
TDnb = \shape #'((0.0 . -0.2)(0.0 . -0.1)(0.0 . -0.1)(-0.0 . -0.2)) Tie
TDnbb = \shape #'((0.0 . -0.1)(0.0 . 0.1)(0.0 . 0.1)(-0.0 . -0.1)) Tie
TDnc = \shape #'((-0.3 . -0.3)(0.0 . -0.0)(0.0 . -0.0)(0.1 . -0.3)) Tie
TDnd = \shape #'((0.0 . -0.2)(0.0 . 0.1)(0.0 . 0.1)(-0.2 . -0.3)) Tie
TDne = \shape #'((0.0 . -0.2)(0.0 . 0.1)(0.0 . 0.1)(0.0 . -0.2)) Tie
TDnf = \shape #'((0.0 . -0.4)(0.0 . -0.6)(0.0 . -0.6)(0.0 . -0.4)) Tie
TDng = \shape #'((0.0 . -0.0)(0.0 . -0.2)(0.0 . -0.2)(0.0 . -0.0)) Tie
TDnh = \shape #'((0.0 . -0.3)(0.0 . -0.4)(0.0 . -0.4)(-0.0 . -0.3)) Tie
TDno = \shape #'((-0.4 . -0.4)(0.0 . -0.4)(0.0 . -0.4)(0.4 . -0.4)) Tie
TDnp = \shape #'((-0.4 . -0.4)(0.0 . -0.6)(0.0 . -0.6)(0.4 . -0.4)) Tie
TDni = \shape #'((0.0 . -0.2)(0.0 . -0.2)(0.0 . -0.2)(-0.6 . -0.2)) Tie
TDnj = \shape #'((0.6 . -0.0)(0.0 . -0.0)(0.0 . -0.0)(-0.6 . -0.0)) Tie
TDnk = \shape #'((0.6 . -0.0)(0.0 . -0.0)(0.0 . -0.0)(-0.6 . -0.0)) Tie
TDnl = \shape #'((-0.6 . -0.4)(0.0 . -0.4)(0.0 . -0.4)(0.0 . -0.4)) Tie
TDnm = \shape #'((0.0 . -0.2)(0.0 . 0.0)(0.0 . 0.0)(-0.3 . -0.2)) Tie
TDnn = \shape #'((0.4 . -0.2)(0.0 . 0.0)(0.0 . 0.0)(-0.1 . -0.2)) Tie
TDno = \shape #'((-0.3 . -0.3)(0.0 . -0.6)(0.0 . -0.6)(0.1 . -0.3)) Tie
TDnp = \shape #'((0.3 . -0.2)(0.0 . 0.1)(0.0 . 0.1)(0.0 . -0.2)) Tie
TDnq = \shape #'((-0.4 . -0.4)(0.0 . -0.2)(0.0 . -0.2)(0.4 . -0.4)) Tie
TDnr = \shape #'((-0.5 . -0.3)(0.0 . -0.4)(0.0 . -0.4)(0.5 . -0.3)) Tie
TDns = \shape #'((0.0 . -0.2)(0.0 . -0.2)(0.0 . -0.2)(-0.0 . -0.2)) Tie
TDnt = \shape #'((0.2 . -0.1)(0.0 . -0.2)(0.0 . -0.2)(-0.0 . -0.2)) Tie
%TOa = \shape #'((-0.4 . -0.0)(2.0 . -0.0)(2.0 . -0.0)(2.0 . -0.0)) Tie

SDn = \shape #'((0.0 . 0.0)(0.0 . -0.6)(0.0 . -0.6)(0.0 . 0.0)) Slur
SDna = \shape #'((0.0 . -0.4)(0.0 . 0.3)(0.0 . 0.0)(0.0 . 0.2)) Slur
SDnb = \shape #'((0.0 . -0.0)(0.0 . -0.7)(0.0 . -0.5)(0.0 . 0.0)) Slur
SDnc = \shape #'((0.2 . -0.2)(0.0 . -0.4)(0.3 . -0.2)(0.0 . -1.0)) Slur
SDnd = \shape #'((0.0 . -0.0)(0.0 . -0.0)(0.0 . -0.0)(0.0 . -0.2)) Slur
SDne = \shape #'((0.0 . -0.0)(0.0 . -0.0)(0.0 . -0.0)(0.0 . -0.4)) Slur
SUp = \shape #'((0.0 . 1.0)(0.0 . 0.0)(0.0 . 0.0)(0.0 . 0.0)) Slur
SUpa = \shape #'((0.0 . 0.6)(0.0 . 0.0)(0.0 . 0.0)(0.0 . 0.0)) Slur
SUpb = \shape #'((0.0 . 0.2)(-0.2 . -0.0)(-0.1 . 0.6)(-0.8 . 0.2)) Slur
SUpc = \shape #'((0.0 . 0.1)(-0.2 . 0.1)(-0.4 . 0.7)(-1.0 . 0.5)) Slur
SUpd = \shape #'((0.0 . 0.4)(-0.0 . -0.2)(-0.0 . 0.6)(-1.0 . 0.0)) Slur
SUpe = \shape #'((0.0 . 0.5)(0.0 . 0.2)(0.0 . 0.2)(0.0 . 0.4)) Slur
SUpf = \shape #'((0.0 . 0.4)(0.0 . 0.2)(0.0 . 0.5)(-0.2 . 0.5)) Slur
SBl = \shape #'((0.0 . 0.0)(0.0 . 0.0)(0.0 . 0.0)(-1.0 . 0.0)) Slur
SIna = \shape #'((0.0 . 0.2)(-0.4 . 0.3)(-0.2 . 0.5)(-0.9 . 0.8)) Slur
SInb = \shape #'((0.0 . 0.2)(-0.4 . 0.5)(-0.2 . 0.5)(-0.7 . 0.6)) Slur
SInc = \shape #'((0.0 . 0.6)(-0.4 . 0.8)(-0.6 . 0.8)(-0.8 . 0.6)) Slur
SIncc = \shape #'((0.0 . 0.4)(-0.4 . 0.8)(-0.6 . 0.8)(-0.8 . 0.6)) Slur
SInd = \shape #'((0.0 . 0.2)(-0.4 . 0.7)(-0.6 . 0.7)(-0.8 . 0.6)) Slur
SIne = \shape #'((0.0 . 0.2)(-0.0 . -0.2)(-0.0 . 0.4)(-0.8 . 0.2)) Slur
SInf = \shape #'((0.0 . 0.3)(-0.4 . 0.7)(-0.6 . 0.6)(-1.0 . 0.4)) Slur
SIng = \shape #'((0.0 . 0.1)(-0.4 . 0.4)(-0.6 . 0.4)(-1.0 . 0.4)) Slur
SOuta = \shape #'((0.0 . 0.2)(0.0 . 0.2)(0.0 . 0.2)(-0.2 . 0.2)) Slur

%
\include "toc.ly"
\include "intro.ly"
\include "intro2/book.ly"
\include "aria/Duo/book.ly"
\include "aria/Trio/book.ly"
\include "aria/Trio/gtr1/book.ly"
\include "aria/Trio/gtr2/book.ly"
\include "aria/Trio/gtr3/book.ly"
\include "blank.ly"
\include "v01/book.ly"
\include "v02/book.ly"
\include "v03/book.ly"
\include "v04/book.ly"
\include "v05/book.ly"
\include "v06/book.ly"
\include "v07/book.ly"
\include "v08/book.ly"
\include "v09/book.ly"
\include "v10/book.ly"
\include "v11/book.ly"
\include "v12/book.ly"
\include "v13/book.ly"
\include "v14/book.ly"
\include "v15/book.ly"
\include "v15/gtr1/book.ly"
\include "v15/gtr2/book.ly"
\include "v15/gtr3/book.ly"
\include "blank.ly"
\include "v16/book.ly"
\include "v17/book.ly"
\include "v18/book.ly"
\include "v19/book.ly"
\include "v20/book.ly"
\include "v21/book.ly"
\include "v22/book.ly"
\include "v23/book.ly"
\include "v24/book.ly"
\include "v25/book.ly"
\include "v26/book.ly"
\include "v27/book.ly"
\include "v28/book.ly"
\include "v29/book.ly"
\include "v30/book.ly"
\include "ornaments/book.ly"
\include "ack.ly"
\include "errata.ly"
\include "copyright.ly"
\include "blank1.ly"
%
