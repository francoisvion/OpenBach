\version "2.18.2"

\include "v22/guitar1.ly"
\include "v22/guitar2.ly"
\include "v22/guitar3.ly"
\include "v22/guitar4.ly"

global = {
  \time 2/2
  \clef "G_8"
  \key g \major
}

\bookpart {

    \paper {
	page-count = #2
%	system-count = #8

        top-system-spacing =
                #'((basic-distance . 12)
                   (minimum-distance . 8)
                   (padding . 0))
%                   (stretchability . 4))

	system-system-spacing =
	    #'((basic-distance . 22)
	       (minimum-distance . 14)
	       (padding . 4)
	       (stretchability . 4))
     }

    \header {
	title = "Variation 22"
	subtitle = "  "
%	subsubtitle = "  "
	copyright = \markup {
		 \fill-line {
		     \tiny {
			\line {Steve Shorter (2014). Hajo Delzelski (2008). \epsfile #X #10 #'"/by-sa.eps" }
		     }
	        }
	}
    }

   \tocItem \markup { Variation 22 }

  \score {
    \new GrandStaff \with {
            \override StaffGrouper.staff-staff-spacing =
                #'((basic-distance . 14)
                   (minimum-distance . 8)
                   (padding . 2))
	}
    <<
	\set GrandStaff.instrumentName =
		\markup {
			\override #'(font-family . "Sans")
			\abs-fontsize #12.0 \bold "Guitar  " 
		}

	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitarone >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitartwo >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitarthree >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitarfour >>
    >>

    \layout {
        \context {
           \Score
%             \override NonMusicalPaperColumn #'line-break-permission = ##f
%            \override NonMusicalPaperColumn #'page-break-permission = ##f
       }
    }
  }
 }

