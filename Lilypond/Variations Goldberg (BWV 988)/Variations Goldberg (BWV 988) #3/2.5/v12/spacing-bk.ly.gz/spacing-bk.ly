\version "2.18.2"

spacing = {
	\repeat unfold 8 { s4 s4 s4 }
	\pageBreak 
	\repeat unfold 8 { s4 s4 s4 }
	\pageBreak 
	\repeat unfold 8 { s4 s4 s4 }
	\pageBreak 
	\repeat unfold 8 { s4 s4 s4 }
}

