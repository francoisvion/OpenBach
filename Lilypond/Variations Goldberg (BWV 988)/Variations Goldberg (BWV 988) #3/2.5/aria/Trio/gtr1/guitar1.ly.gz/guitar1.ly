\version "2.18.2"

 voiceone = \relative c'' {
 \override Staff.NoteCollision #'merge-differently-dotted = ##t
 \set harmonicDots = ##t
 \set Staff.instrumentName = "Gtr1 "

 \repeat volta 2 {
	%1-5
        \stemDown g'4
	 g4( a8.\mordent) b16
        a8
	\stemUp \slurDown \SInd \appoggiatura g16 \stemNeutral fis8
	\stemUp \SInc \appoggiatura e16 \stemNeutral d2
        \stemUp g,4\mordent g4.\downprall fis16 g16
        a32[( g32 fis16) g32( fis32 e16)] \grace e8 < d\harmonic >2
        \stemDown d'4 d4^( e8.\mordent) f16

        %6-10
        e8
   	\once \override Slur #'control-points = #'((.5 . .4) (1.0 . -0.8) (1.4 . -0.3) (1.8 . -.5))
	\stemUp \appoggiatura d16 \stemNeutral c8
   	\once \override Slur #'control-points = #'((.5 . -0.7) (.8 . -1.0) (1.4 . -1.6) (2.2 . -1.3))
	\stemUp \appoggiatura b16 a4.\harmonic \stemDown fis'8\turn
        \stemDown g32[^( fis16.) a32^( g16.)] fis32[^( e16.) d32^( c16.)]
   	\once \override Slur #'control-points = #'((.5 . 3.0) (0.6 . 4.0) (1.8 . 4.5) (2.4 . 3.9))
	\stemUp \appoggiatura c8 \stemNeutral a'8. c,16
        { \stemUp b32[(\harmonic g16.)\harmonic fis8] \appoggiatura fis8 g2\mordent }
	\stemNeutral b4 b4^( cis8.\mordent) d16
	<<
	    { d16 cis16 b16 a16\harmonic d2\harmonic } \\
	    { s4. s4. } \\
	    { e,8.\rest \stemDown a16_~\harmonic a2\harmonic }
	>>

        %11-15
 	\stemNeutral \tieNeutral
        < b e g >4\arpeggio \clef "G_8" g4.\downprall fis16 g16
        g8
	\stemUp \slurDown \appoggiatura fis16 \stemNeutral e8 cis4.\lineprall e8
        a16^( g16 fis16 e16) d8 a4_~ a32 b32 c16
        b16( a16 g16 fis16) e8 \stemUp \grace d'16 \stemNeutral cis4~ cis32 d32 e16
        d16^( cis16 b16 a16) g'8 b,4 cis8

        %16
        \stemUp \grace cis16 \stemNeutral d8 ~ [ d32 e32 d32 cis32 ] \stemUp \grace cis8  \stemNeutral d2 
    }

 \break

    \repeat volta 2 {
	\stemNeutral
        a4\mordent a4_~\downprall a16[ a32^( b32 c32 d32 e16)]
        \stemUp \grace e16 d8
        \SInb \appoggiatura c16 b8 \SUpe \appoggiatura a8 g4. \stemNeutral g'8
        \stemUp \appoggiatura fis16 \stemNeutral e8. fis32 dis32
        \stemUp \appoggiatura dis8 \stemNeutral e4.\mordent a32 b32 a32 g32
        a8. fis16 \stemUp \SUpa \appoggiatura e16 \stemNeutral dis4. b8

        %21-25
        \grace{\graceSchleifer e16} g8. fis16
	\stemUp \grace fis8 \stemNeutral \TUpo e4^~ e16[ b16 c32^( b32 a32 b32)]
        g'32[^( e16.) fis32^( dis16.)]
	\stemUp \grace dis8 \stemNeutral \TUpo e4^~ e16 g,16 fis16 e16
        fis8. e'16 \stemUp \grace e16 \stemNeutral dis8 \grace{\GraceSchleifer e16} a8 g8 fis8
	<<
            {\grace fis16 \stemUp e8. fis32 dis32 \grace dis8 < e\harmonic >2 } \\
	    { e,2\rest s4}
	>>

	\clef treble

	\stemNeutral

	e''8
	\slurDown 
        \stemUp \appoggiatura d16 \stemNeutral c8
        \stemUp \appoggiatura b16 \stemNeutral a4. b16[ c16]

	\stemNeutral

        %26-30
        d32[^( c32 b16) c32^( b32 a16)] \grace a8 \stemUp g4. a16 b16
        << %27-28
            { c16 d16 c16 b16 c16 a16 e16 a16 c4 ~ | c16 d16 c16 b16 c16 a16 fis16 a16 c16 e16 d16 c16 } \\
            { r4. e,4. | fis4. fis4. }
        >>
        << %29-30
            { b16 c16 b16 a16 b16 g16 d16 g16 b16 g16 c16 d16 | e16 f16 e16 d16 e16 c16 g16 c16 e16 c16 fis16 g16 } \\
            { g,8. r8. d8. \TUpb g8.~ | g4. g8. c8. }
        >>
 
       %31-32
        \stemNeutral a'16 c,16 b16 a16 b16 c16 d16 g,16 b16 a16 g16 fis16
        <<
        { \TInb < g\harmonic >4^~ < g\harmonic >16 < d\harmonic >16 < g\harmonic >16 fis16 \slurDown \appoggiatura fis8 \slurDown g4 } \\
        { c,16\rest c16 b16 a16 b2 }
        >>
   }
}

 voicetwo = \relative c {

    \repeat unfold 23 { s4 s s } |

    \stemDown

    s2 \stemDown \extendLV #3.0 e4\harmonic \laissezVibrer |

    \hideNotes

    a4 a16 a a a a4 |

 }

 guitarone = << \voiceone \\ \voicetwo >>


