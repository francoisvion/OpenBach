\version "2.18.2"

\include "v29/spacing-bk.ly"
\include "v29/guitar1.ly"
\include "v29/guitar2.ly"

global = {
  \time 3/4
  \key g \major
  \clef "G_8"
}

\bookpart {

    \paper {
	page-count = #4
%	system-count = #8

        top-system-spacing =
                #'((basic-distance . 12)
                   (minimum-distance . 8)
                   (padding . 0))
%                   (stretchability . 4))

	system-system-spacing =
	    #'((basic-distance . 24)
	       (minimum-distance . 16)
	       (padding . 4)
	       (stretchability . 8))
    }

    \header {
	title = "Variation 29"
	subtitle = "   "
	subsubtitle = "   "
	copyright = \markup {
		 \fill-line {
		     \tiny {
			\line {Steve Shorter (2014). Hajo Delzelski (2008). \epsfile #X #10 #'"/by-sa.eps" }
		     }
	        }
	}
    }

    \tocItem \markup { Variation 29 }

  \score {
    \new GrandStaff \with {
            \override StaffGrouper.staff-staff-spacing =
                #'((basic-distance . 24)
                   (minimum-distance . 16)
                   (padding . 4))
	}
    <<
	\set GrandStaff.instrumentName =
		\markup {
			\override #'(font-family . "Sans")
			\abs-fontsize #12.0 \bold "Guitar  " 
		}

	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \spacing \guitarone >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitartwo >>
    >>

    \layout {
        \context {
           \Score
             \override NonMusicalPaperColumn #'line-break-permission = ##f
            \override NonMusicalPaperColumn #'page-break-permission = ##f
       }
    }
  }
}

