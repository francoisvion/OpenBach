\version "2.18.2"

\include "v30/guitar1.ly"
\include "v30/guitar2.ly"
\include "v30/guitar3.ly"
\include "v30/guitar4.ly"

global = {
  \time 4/4
  \key g \major
  \clef "G_8"
}

\bookpart {
 \paper {
	page-count = #2
	systems-per-page = #3
	system-count = #6
%	min-systems-per-page = #4

	top-system-spacing =
                #'((basic-distance . 12)
                   (minimum-distance . 8)
                   (padding . 0))
%                   (stretchability . 4))

	system-system-spacing =
	    #'((basic-distance . 18)
	       (minimum-distance . 8)
	       (padding . 4)
	       (stretchability . 4))
 }

  \header {
	title = "Variation 30"
	subtitle = "  "
%	subsubtitle = "  "

	meter = \markup {
		\translate #`(-0 . 2 ) { \hspace #4 \roman \fontsize #2.0 "Quodlibet" }
	   }

	copyright = \markup {
		 \fill-line {
		     \tiny {
			\line {Steve Shorter (2014). Hajo Delzelski (2008). \epsfile #X #10 #'"./by-sa.eps" }
		     }
	        }
	}
    }

    \tocItem \markup { "Variation 30" \hspace #10 "Quodlibet" }

   \score {
    \new GrandStaff \with {
            \override StaffGrouper.staff-staff-spacing =
                #'((basic-distance . 12)
                   (minimum-distance . 8)
                   (padding . 2))
	}
    <<
	\set GrandStaff.instrumentName =
		\markup {
			\override #'(font-family . "Sans")
			\abs-fontsize #12.0 \bold "Guitar  " 
		}

	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitarone >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitartwo >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitarthree >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitarfour >>
    >>

    \layout {
        \context {
           \Score
%             \override NonMusicalPaperColumn #'line-break-permission = ##f
%            \override NonMusicalPaperColumn #'page-break-permission = ##f
       }
    }
  }
}

