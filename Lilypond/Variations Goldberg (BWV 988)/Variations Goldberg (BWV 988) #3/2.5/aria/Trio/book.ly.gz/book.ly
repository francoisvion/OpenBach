\version "2.18.2"

\include "aria/Trio/spacing-bk.ly"
\include "aria/Trio/guitar1.ly"
\include "aria/Trio/guitar2.ly"
\include "aria/Trio/guitar3.ly"

global = {
  \time 3/4
  \key g \major
 \set harmonicDots = ##t
}

\bookpart {

   \paper {
	print-first-page-number = ##t
%	page-count = #4

	bottom-margin = 14 \mm

        top-system-spacing =
                #'((basic-distance . 14)
                   (minimum-distance . 10)
                   (padding . 2))
%                   (stretchability . 4))


	system-system-spacing =
	    #'((basic-distance . 28)
	       (minimum-distance . 18)
	       (padding . 4)
	       (stretchability . 12))
   }

    \header {

 title = \markup \center-column {
                \null
                \null
                \fontsize #5.2
                "Aria"
        }

  subtitle = \markup \center-column {
		" "
                \null
		\fontsize #2.6 "\"Goldberg\""
                \null
        }

  composer = \markup \center-column {
        \fontsize #1.0
         "J. S. Bach (1685 - 1750)"
        }

  arranger = \markup \center-column {
        \fontsize #1.0
         "Steve Shorter (2018)"
                \null
        }

	poet = ""
	meter = ""
	piece = "2.5"
	style = "Baroque"
	copyright = \markup {
			 \fill-line {
			     \tiny {
				\line {Steve Shorter (2014). JD Erickson (2007). \epsfile #X #10 #'"/by-sa.eps" }
			     }
		        }
		}
	maintainer = "Steve Shorter"
	lastupdated = "2025/06"
 } 

   \score {
    \new GrandStaff \with {
            \override StaffGrouper.staff-staff-spacing =
                #'((basic-distance . 18)
                   (minimum-distance . 12)
                   (padding . 4))
	}
    <<
	\set GrandStaff.instrumentName =
		\markup {
			\override #'(font-family . "Sans")
			\abs-fontsize #12.0 \bold "Guitar  " 
		}

	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \spacing \guitarone >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitartwo >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitarthree >>
    >>

    \layout {
        \context {
          \Score
            \override NonMusicalPaperColumn #'line-break-permission = ##f
            \override NonMusicalPaperColumn #'page-break-permission = ##f
       }
    }
  }

}
