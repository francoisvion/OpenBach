\version "2.18.2"

%\include "v02/spacing-bk.ly"
\include "v02/guitar1.ly"
\include "v02/guitar2.ly"
\include "v02/guitar3.ly"

global = {
  \time 2/4
  \key g \major
  \clef "G_8"
}

\bookpart {

    \paper {
	page-count = #2
%	system-count = #8

        top-system-spacing =
                #'((basic-distance . 12)
                   (minimum-distance . 8)
                   (padding . 0))
%                   (stretchability . 4))

	system-system-spacing =
	    #'((basic-distance . 20)
	       (minimum-distance . 16)
	       (padding . 4)
	       (stretchability . 12))
	}

    \header {
	title = "Variation 02"
	subtitle = "   "
%	subsubtitle = "   "

	copyright = \markup {
		 \fill-line {
		     \tiny {
			\line {Steve Shorter (2014). JD Erickson (2007). \epsfile #X #10 #'"by-sa.eps" }
		     }
	        }
	}
    }

   \tocItem \markup { Variation 02 }

  \score {
    \new GrandStaff \with {
            \override StaffGrouper.staff-staff-spacing =
                #'((basic-distance . 16)
                   (minimum-distance . 10)
                   (padding . 0))
	}
    <<
	\set GrandStaff.instrumentName =
		\markup {
			\override #'(font-family . "Sans")
			\abs-fontsize #12.0 \bold "Guitar  " 
		}

	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitarone >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitartwo >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitarthree >>
    >>

    \layout {
        \context {
           \Score
%             \override NonMusicalPaperColumn #'line-break-permission = ##f
%            \override NonMusicalPaperColumn #'page-break-permission = ##f
       }
    }
  }
}

