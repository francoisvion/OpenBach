\version "2.18.2"

spacing = {
	\repeat unfold 2 { s4 s4 s4 }
    \break
	\repeat unfold 2 { s4 s4 s4 }
    \break
	\repeat unfold 2 { s4 s4 s4 }
    \break
	\repeat unfold 2 { s4 s4 s4 }
    \pageBreak
	\repeat unfold 2 { s4 s4 s4 }
    \break
	\repeat unfold 2 { s4 s4 s4 }
    \break
	\repeat unfold 2 { s4 s4 s4 }
    \break
	\repeat unfold 2 { s4 s4 s4 }
    \pageBreak
	\repeat unfold 2 { s4 s4 s4 }
    \break
	\repeat unfold 2 { s4 s4 s4 }
    \break
	\repeat unfold 2 { s4 s4 s4 }
    \break
	\repeat unfold 2 { s4 s4 s4 }
    \pageBreak
	\repeat unfold 2 { s4 s4 s4 }
    \break
	\repeat unfold 2 { s4 s4 s4 }
    \break
	\repeat unfold 2 { s4 s4 s4 }
    \break
	\repeat unfold 2 { s4 s4 s4 }
}

