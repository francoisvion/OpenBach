\version "2.18.2"

\include "aria/Duo/guitar1.ly"
\include "aria/Duo/guitar2.ly"

global = {
  \time 3/4
  \key g \major
  \set harmonicDots = ##t
}

\bookpart {
    \paper {
	page-count = #2
	system-count = #8

        top-system-spacing =
                #'((basic-distance . 18)
                   (minimum-distance . 10)
                   (padding . 0))
%                   (stretchability . 4))

	system-system-spacing =
	    #'((basic-distance . 20)
	       (minimum-distance . 16)
	       (padding . 4)
	       (stretchability . 12))
	}

    \header {
 title = \markup \center-column {
                \null
                \null
                \fontsize #5.2
                "Aria"
        }

  subtitle = \markup \center-column {
		" "
                \null
		\fontsize #2.6 "\"Goldberg\""
                \null
        }

  composer = \markup \center-column {
        \fontsize #1.0
         "J. S. Bach (1685 - 1750)"
        }

  arranger = \markup \center-column {
        \fontsize #1.0
         "Steve Shorter (2018)"
                \null
        }

	poet = ""
	meter = ""
	piece = "2.5"
	style = "Baroque"
	copyright = \markup {
			 \fill-line {
			     \tiny {
				\line {Steve Shorter (2014). JD Erickson (2007). \epsfile #X #10 #'"/by-sa.eps" }
			     }
		        }
		}
	maintainer = "Steve Shorter"
	lastupdated = "2025"
	}

 \tocItem \markup { Aria }

 \score {
    \new GrandStaff \with {
            \override StaffGrouper.staff-staff-spacing =
                #'((basic-distance . 16)
                   (minimum-distance . 10)
                   (padding . 0))
	}
    <<
	\set GrandStaff.instrumentName =
		\markup {
			\override #'(font-family . "Sans")
			\abs-fontsize #12.0 \bold "Guitar  " 
		}

	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitarone >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitartwo >>
    >>

    \layout {
        \context {
           \Score
%             \override NonMusicalPaperColumn #'line-break-permission = ##f
%            \override NonMusicalPaperColumn #'page-break-permission = ##f
       }
    }
  }
}
