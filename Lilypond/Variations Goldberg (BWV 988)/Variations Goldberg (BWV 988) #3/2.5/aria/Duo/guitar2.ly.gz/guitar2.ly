\version "2.18.2"

 voiceone = \relative c' {
 \clef "G_8"
 \override Staff.NoteCollision #'merge-differently-dotted = ##t
 \set fingeringOrientations = #'(left)
 \set harmonicDots = ##t
 \override Fingering.staff-padding = #'()

    r4 f\rest d4 | r4 f\rest d4 |
    r r cis4 |
    \set fingeringOrientations = #'(left)
    d4\rest d\rest a4  
 \break
     d4\rest d\rest g,4 | d'4\rest d4\rest a4 |
     b8\rest \stemUp \TUp < c-4 >8^~ c8[ < b-2 >16 a16]  g16^\4 fis16 e16
     \once \override Fingering.extra-offset = #'(5.0 . -3.4)
     fis16_2 |
     < g-0 >8 < a-1 >8 < b-3 >2 |
 \break
    f'4\rest f4\rest \stemUp < e-0 >4 | s2. | < b-0 g'-4 >2. |

     %12
    \set fingeringOrientations = #'(right)
    < cis,-3 >8
    \set fingeringOrientations = #'(left)
    < d-0 >8 < e-1 >2 |
 \break
    b'4\rest b\rest d,4 | b'4\rest s4 e,4 |
    < fis-3 >4 e8. fis16 \Tla g4-~ | g4 < fis-2 >2 |

 \pageBreak

    \mergeDifferentlyHeadedOn 
    d8 e8 fis2^\mordent | b,8 < c-1 >8 < d-0 >2 |
    < c-2 >8 e8 g4 fis8^\prallprall e8 |
    \set fingeringOrientations = #'(right)
    < dis-1 >8 < e-1 >8
    \set fingeringOrientations = #'(left)
    < fis-4 >2 |
 \break
     g8\rest a8^\4 g8^\prallprall fis8 g4 |
     g8\rest < a-1^\3 >8 g8^\prallprall fis8 < g-0> < b-4 > 

    % 23-27
    \stemUp < fis-3 >4. < c'-4^\3 >8 < b-4 >
    \TInn < dis,_1 a'~ > | < e-1 a >4 g2 |
    < e'-0 >2 < a,-2 >4~ |
    a8[ < fis-4_\4 >8] \slurDown
    \once \override Fingering.font-size = #-5
    \appoggiatura < e-2 >16
    \set fingeringOrientations = #'(right)
    \once \override Fingering.extra-offset = #'(-1.0 . -1.0)
    < d-0 >8 e16 fis16 g16 fis16
    \set fingeringOrientations = #'(left)
    \TUpa g8~ | g8 < e-1 >8 < a-4 >8 \TUpr < e'-0 >8~ e16 < b'^4 > < a^4 > < g^2 > |
    
    % 28-30
    < fis-2 >4. b,8\rest b4\rest | s2. | s2. |

     %31-32
    s2. | s2. |
 }

 voicetwo = \relative c' {
    \set fingeringOrientations = #'(left)
    \override Fingering.staff-padding = #'()
    \stemDown
    s4 b2 |  s4 a2 |  s4 g2 | s4 fis2 |
    s4 d2 | s4 e4. s8 | s2. | s2. |
    s4 < b'-0 >2 | \stemUp < a-4 >4 s2 |
    \stemUp e8\rest b8 e4. < d-0 >8 | s2. | s4 \stemDown a2 | s4 b4 s4 |
 }
 voicethree = \relative c' {
    \set fingeringOrientations = #'(left)
    \repeat unfold 24 { s2. }
    \stemDown
    g4\rest < e-1 >2 |
 }

 voicefour = \relative c' {
    \set fingeringOrientations = #'(left)
    \stemDown
    < g-3_\4 >2. | < fis-3 >2. | < e-1 >2. |
    \once \override Tie #'control-points = #'((1.5 . -3) (5.5 . -5.5) (16.5 . -5.7) (20.8 . -3.2))
    < d-4_\5 >2_~  d8 c8 | < b-1 >2. |
    \once \override Tie #'control-points = #'(( 1.3 . -3.7) (5 . -6) (12 . -6) (15.0 . -3.7))
    < c-2 >2_~ c8 d8 e8 < c-1 >8 < d-3 >2 |
    < g,-1 >4. [ < d'-0 >8 < e-1 >8.\mordent < fis-2 >16 ] 
    \once \override Tie #'control-points = #'((1.2 . -1.6) (6 . -5.5) (16 . -5.5) (22.2 . -1.6))
    < g-2_\3_\4 >2._~ |
    \set fingeringOrientations = #'(right)
    < g-0 >4
    \set fingeringOrientations = #'(left)
    \stemUp < fis-1 >8^\prallprall < e-1 >8 fis8 b,8 |
    \stemDown
    e,4. e8 fis8 g8 |
    \once \override Fingering.extra-offset = #'(0.2 . -0.3) % this is fingering for g in bass!!
    < a_4 >4. < b-1 >8 a8 g8 | < fis-1 >2. | < g-2 >2. |
    < a-0 >2. | < d-3_\5 >4~ d8 < a-0 >8 < d-4 >4 |
    < d-4_\5 >2 < c-1 >4 | < b-4_\6 >4. < a-0 >8 < b-1 >4 | c4. b8 a4 |
    \once \override Fingering.extra-offset = #'(0.2 . -0.0)
    < b_2 >4. a8 g8 fis8 |
    e2 d'4 | < c-2 >2 b4 |
    a8 < c-2 > b a
    \once \override Fingering.extra-offset = #'(0.2 . -0.0)
    < b_2 >4 | e8 b e, b' e d | < c-3 >2. | < b-1 >2. |
    < a-0 >4. < g'-2 >8 < fis-1 > < e-1 > | < d-0 >8 < a-0 > d c b a |
    \stemNeutral < g-1 >8 d' g f e d |
    c8 g' c b a g |
    fis8 d8 g8 b8 d8 d,8 |
    < g-3_\4 >4. < d-0 >8 g,4 |
 }

guitartwo = << \voiceone \\ \voicetwo \\ \voicethree \\ \voicefour >>

