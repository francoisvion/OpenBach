\version "2.18.2"

\bookpart {

    \paper { print-first-page-number = ##f }

    \header { tagline = "" }


\markup { \fill-line {  \center-column {

    \null
    \null
    \null
    \null
    \null
    \null
    \large \bold \fontsize #12 "Goldberg Variations"
    \null
    \null
    \null
    \null
    \null
    \null
    \null
    \null
    \null
    \sans \fontsize #11 "J. S. Bach"
    \null
    \null
    \null
    \null
    \null
    \fontsize #7 "BWV 988"
    \null
    \null
    \null
    \null
    \null
    \null
    \null
    \null
    \null
    \fontsize #6 "For Guitar Ensemble"
    \null
    \null
    \null
    \null
    \null
    \null
    \null
    \null
    \null
    \fontsize #2 "Transcribed and Engraved"
    \null
    \fontsize #2 "by"
    \null
    \null
    \fontsize #6 "Steve Shorter"
    \null
    \null
    \null
    }
  }
}
}


