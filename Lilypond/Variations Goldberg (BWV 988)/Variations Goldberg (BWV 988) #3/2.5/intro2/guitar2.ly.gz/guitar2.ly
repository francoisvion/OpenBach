\version "2.18.2"

 voiceone = \relative c' {
 \clef "G_8"
 \override Staff.NoteCollision #'merge-differently-dotted = ##t
 \set fingeringOrientations = #'(left)
 \set harmonicDots = ##t
 \override Fingering.staff-padding = #'()

    r4 f\rest d4 | r4 f\rest d4 |
    r r cis4 |
    d4\rest d\rest a4  
 }

 voicetwo = \relative c' {
    \set fingeringOrientations = #'(left)
    \override Fingering.staff-padding = #'()
    \stemDown
    s4  b2 |  s4 a2 | s4 g2 | s4 fis2 |
 }

 voicethree = \relative c' {
    \set fingeringOrientations = #'(left)
 }

 voicefour = \relative c' {
    \set fingeringOrientations = #'(left)
    \stemDown
    < g-3_\4 >2. | fis2. | e2. |
 \once \override Tie #'control-points = #'((1.5 . -3) (5.5 . -5.5) (12.0 . -5.7) (16.0 . -3.2))

    d2_~  d8 c8 |
 }

guitartwo = << \voiceone \\ \voicetwo \\ \voicethree \\ \voicefour >>

