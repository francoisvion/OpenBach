#!/bin/bash

lilypond frontpage.ly
lilypond version.ly
lilypond dedication.ly
lilypond blank.ly
lilypond bwv-988.ly

pdftk A=frontpage.pdf B=version.pdf C=goldberg_title.pdf D=dedication.pdf E=bwv-988.pdf F=blank.pdf cat A B C D E F output BWV-988-2.5.pdf

/bin/echo "running qpdf..."

/usr/bin/qpdf --linearize BWV-988-2.5.pdf B.pdf
mv B.pdf BWV-988-2.5.pdf

