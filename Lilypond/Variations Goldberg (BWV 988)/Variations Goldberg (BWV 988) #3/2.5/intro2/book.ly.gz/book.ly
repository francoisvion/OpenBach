\version "2.18.2"

\include "intro2/guitar1.ly"
\include "intro2/guitar2.ly"

global = {
  \time 3/4
  \key g \major
}

\bookpart {

    \paper {
        bottom-margin = 12 \mm
        print-page-number = ##t 
	page-count = #1
%	system-count = #8
	#(set-paper-size "arch a")

  tagline = ""

  }

    \header {

	title = \markup \column {
		" "
		"Introduction to Version 2.0"
		" "
	}
        copyright = \markup \column {
           \fill-line {
                 \tiny {
                    \line { Steve Shorter (2025). \epsfile #X #10 #'"by-sa.eps" }
                 }
           }
        }
    }

 \markup \column {
        "        "
        "        "
	\fontsize #1 {"                After 10 years since the release of Version 1.0, there is much to be considered." 
	"  "
	"                The changes of Version 2.0, are about readability and spacing."
	"  "
        "                The use of the Grand Staff is about clarity, authority, and I like the soft curves."
        "The use of the Treble Cleff is mostly technical."
	"  "
        "                Perhaps an example from the Aria."
	"  "
	"  "
	"  "
        }
    }


 \tocItem \markup { Introduction to Version 2.0 }

 \score {
    \new GrandStaff \with {
            \override StaffGrouper.staff-staff-spacing =
                #'((basic-distance . 18)
                   (minimum-distance . 12)
                   (padding . 0))
	}
    <<
	\set GrandStaff.instrumentName =
		\markup {
			\override #'(font-family . "Sans")
			\abs-fontsize #10.0 \bold "Guitar  " 
		}

	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitarone >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitartwo >>
    >>

    \layout { #(layout-set-staff-size 16) }
}

\markup \column {
        "        "
        "        "
        "        "
	\fontsize #1 {"                Notice the 2 clefs. The top is the normal Treble Clef. The bottom is the \"normal\" Guitar Clef."
        "They are quite different. Solo Guitar score is written in a special clef to accomodate the range of the"
        "instrument. It is quite ideal for that purpose. But in ensemble arrangement, with adequate counterpoint,"
        "there is a need for the Treble Clef to save space and improve readability."
        "        "
        "              The first note \"g\" in the top clef, is found on the 15th fret of the guitar. The 4th ledger line of"
        "the Guitar Clef. To continue an entire piece with the top Guitar written in ledger lines demands a"
        "different solution. It is common to take short periods of high notes and use ottava, but for an entire piece"
        "is rediculous when a simple change of clef is all that is neccessary."
        "        "
        "              Where there are no other solutions, the Guitar Clef has been replaced by the Treble Clef"
        "whenever it saves space and improves readability. The Treble Clef has been used in the Aria and"
        "Variations 1, 4, 9, 10, 12, 16, 18, 19, 21, 22, 24 and 26."
        "        "
        "             In the process of craftng Version 2.0, I had hoped to find some wrong notes. However, all I could"
        "find in Version 1.3 was a wrong octave in the last chord of Variation 16. I probably missed something ;-)."
        "I fixed some bad ties and stem directions. Made AccidentalStyle more modern. Improved Aria Trio and"
        "Variation 30."
        "        "
        "            In case of errors or other reason, I can be reached at steve@linuxsuite.org"             
	\vspace #12
        }
    }
}

