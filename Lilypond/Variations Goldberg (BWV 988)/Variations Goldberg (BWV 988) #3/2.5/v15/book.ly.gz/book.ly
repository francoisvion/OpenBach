\version "2.18.2"

\include "v15/guitar1.ly"
\include "v15/guitar2.ly"
\include "v15/guitar3.ly"

global = {
  \time 2/4
  \key g \minor
  \clef "G_8"
}

\bookpart {

    \paper { 
	page-count = #4
%	system-count = #8

	top-system-spacing =
                #'((basic-distance . 12)
                   (minimum-distance . 8)
                   (padding . 0))
%                   (stretchability . 4))

	system-system-spacing =
	    #'((basic-distance . 20)
	       (minimum-distance . 8)
	       (padding . 4)
	       (stretchability . 4))
	}

    \header {
	title = "Variation 15"
	subtitle = "   "
%	subsubtitle = "   "

	meter = \markup {
		\translate #`( 0 . 2 ) { \hspace #4 \roman \fontsize #1.0 "Canon at the Fifth" }
	   }

%        poet  = "   "
%        piece = "  "
	copyright = \markup {
		 \fill-line {
		     \tiny {
			\line {Steve Shorter (2014). Benjamin Esham (2007). \epsfile #X #10 #'"/by-sa.eps" }
		     }
	        }
	}
    }

    \tocItem \markup { "Variation 15" \hspace #10 "Canon at the Fifth" }

   \score {
    \new GrandStaff \with {
            \override StaffGrouper.staff-staff-spacing =
                #'((basic-distance . 8)
                   (minimum-distance . 4)
                   (padding . 0))
	}
    <<
	\set GrandStaff.instrumentName =
		\markup {
			\override #'(font-family . "Sans")
			\abs-fontsize #12.0 \bold "Guitar  " 
		}

	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitarone >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitartwo >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitarthree >>
    >>

    \layout {
        \context {
           \Score
%             \override NonMusicalPaperColumn #'line-break-permission = ##f
%            \override NonMusicalPaperColumn #'page-break-permission = ##f
       }
    }
  }
 }

