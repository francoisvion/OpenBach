\version "2.18.2"

\include "ornaments/guitar1.ly"
\include "ornaments/guitar2.ly"

global = {
  \clef "G_8"
}

\bookpart {

    \paper {
	indent = 0 
        bottom-margin = 20 \mm
    }

    \header {
	title = "Table of Ornaments"
	subtitle = " "
	subsubtitle = " "

  copyright = \markup \column {
		" "
		" "
		" "
		" "
		" "
		" "
		" "
		" "
		" "
		" "
		" "
		\fill-line {
			\tiny {
				\line {Steve Shorter (2014). \epsfile #X #10 #'"by-sa.eps" }
			}
		}
	}

  }

   \tocItem \markup { Table of Ornaments }


\markup { \column {
	" "
	" "
	\fontsize #1 {
	" "
	"         This table of ornaments is taken from J. S. Bach's \"Klavierbüchlein für Wilhelm Friedemann"
	"Bach\", written for Bach's eldest son. It was meant to be schematic rather than literal."
	"Ornaments in this period were typically improvised. Even when notated the length of the"
	"ornament and its articulation was dependent on its context and the performers preference."
	" "
	" "
	" "
	" "
	" "
	" "
	}
    }
}
    \score {
	\new StaffGroup \with {
	    \override StaffGrouper #'staff-staff-spacing =
		#'((basic-distance . 10)
		   (minimum-distance . 8)
		   (padding . 8))
            }
	<<
	    \new Staff \with { \remove "Time_signature_engraver" }
		<< \global \guitarone >>
	    \new Staff \with { \remove "Time_signature_engraver" }
		<< \global \guitartwo >>
	>>
	

	\layout { }
    }
}

