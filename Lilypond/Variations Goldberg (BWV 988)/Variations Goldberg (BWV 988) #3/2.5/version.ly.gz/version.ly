\version "2.18.2"

%date = #(strftime "%d-%m-%Y" (localtime (current-time)))

\bookpart {

    \paper {
        #(set-paper-size "arch a")
        print-first-page-number = ##f

        bottom-margin = 18 \mm

    }

    \header {
	tagline = \markup {
          \simple #(strftime "%c" (localtime (current-time)))"Version 2.5               "
       }

    }
       \markup " "

}

