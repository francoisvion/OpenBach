\version "2.18.2"

\include "v15/gtr2/guitar2.ly"

global = {
  \time 2/4
  \key g \minor
 \set harmonicDots = ##t
}

\bookpart {

   \paper {
	print-first-page-number = ##t
	page-count = #1
	system-count = #9

	bottom-margin = 12 \mm

        top-system-spacing =
                #'((basic-distance . 10)
                   (minimum-distance . 8)
                   (padding . 2))
%                   (stretchability . 4))


	system-system-spacing =
	    #'((basic-distance . 14)
	       (minimum-distance . 10)
	       (padding . 4)
	       (stretchability . 4))
   }

    \header {

 title = \markup \center-column {
                "Variation 15"
		\null
        }

  composer = \markup \center-column {
        \fontsize #1.0
         "J. S. Bach (1685 - 1750)"
        }

  arranger = \markup \center-column {
        \fontsize #1.0
         "Steve Shorter (2018)"
                \null
        }

%	poet = ""
%	meter = ""
%	piece = "2.0"
	style = "Baroque"
	copyright = \markup {
			 \fill-line {
			     \tiny {
				\line {Steve Shorter (2014). JD Erickson (2007). \epsfile #X #10 #'"by-sa.eps" }
			     }
		        }
		}
	maintainer = "Steve Shorter"
	lastupdated = "2025/06"
 } 

   \score {
   \new StaffGroup \with {
            \override StaffGrouper #'staff-staff-spacing =
                #'((basic-distance . 12)
                   (minimum-distance . 10)
                   (padding . 2))
    }
    <<
        \new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitartwo >>
    >>

    \layout {
	#(layout-set-staff-size 20)
        \context {
          \Score
%            \override NonMusicalPaperColumn #'line-break-permission = ##f
%            \override NonMusicalPaperColumn #'page-break-permission = ##f
       }
    }
  }

}
