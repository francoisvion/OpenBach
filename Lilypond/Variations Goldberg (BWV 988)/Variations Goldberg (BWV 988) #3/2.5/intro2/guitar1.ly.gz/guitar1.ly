 guitarone = \relative c'' {
 \override Staff.NoteCollision #'merge-differently-dotted = ##t
 \set harmonicDots = ##t
 \set fingeringOrientations = #'(left)
    %1-5
    \stemDown < g'-1^\1 >4
    \once \override Slur #'control-points = #'((1.0 . 3.5) (2 . 4.5) (5 . 4.5) (6 . 4.0))
    g4 ( a8.\mordent) b16 a8
    \stemUp \slurDown \SInd \appoggiatura g16 \stemDown fis8
    \stemUp \slurDown \SInc \appoggiatura e16  d2
    \stemUp g,4\mordent g4.\downprall fis16 g16
    a32[( g32 fis16) g32( fis32 e16)]
    \once \override Fingering.font-size = #-5
    \grace e8 d2\harmonic
}


