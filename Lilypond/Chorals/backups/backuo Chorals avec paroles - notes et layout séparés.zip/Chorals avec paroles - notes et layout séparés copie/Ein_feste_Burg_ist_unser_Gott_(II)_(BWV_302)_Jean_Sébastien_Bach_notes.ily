sopranoMusic = {
  \voiceOne
  \repeat volta 2 {
    \partial 4  d''4
    d'' d'' a'8 [b'] cis''4
    d''8 [cis''] b'4 a'\fermata d''
    cis'' b' a' b'
    g'8 [fis'] e'4 d'\fermata }
  \partial 4  d'
  a' b' a' gis'
  a'2\fermata d'4 a'
  b' cis'' d''\fermata cis''
  d''8 cis'' b'4 a'\fermata
  \partial 4  b'
  b' a' b'8 [a'] g'4
  fis'\fermata d'' cis'' b'
  a' b'8 [a'] g'4 fis'
  e'2 d'4\fermata \fine
}

altoMusic = {
  \voiceTwo
  \repeat volta 2 {
    \partial 4  a'4
    d' d'8 [e'] fis'4 g'
    a' gis' e'\fermata b'
    e' d' cis' b
    cis'8 d'4 cis'8 d'4\fermata }
  \partial 4  d'
  cis' d' e'8 [d'] b4
  cis'2\fermata d'8 [e'] fis'4
  g'8 [fis'] e'4 fis'\fermata fis'
  fis'16 [gis'] a'4 gis'8 e'4\fermata
  \partial 4 g'
  g' dis'8 [e'] fis'4 e'
  dis'\fermata fis' fis'8 [e'] d' [e']
  fis' [e'] d'4 e'8 [a] d'4~
  d' cis' a\fermata \fine
}

tenorMusic = {
  \voiceOne
  \repeat volta 2 {
    \partial 4  fis'4
    fis' b8 [cis'] d'4 e'
    fis'4. e'16 [d'] cis'4\fermata fis8 [gis]
    ais4 b fis'8 [e'] d'4
    e'8 a4 g8 fis4\fermata }
  \partial 4  fis8 [g]
  a4 gis8 [fis] e [fis] e4
  e2\fermata a4 d'
  d' a a\fermata a
  b8 e' fis' [e'] cis'4\fermata
  \partial 4 e'
  d'8 [e'] fis'4 b b
  b\fermata b a b8 [cis']
  d'4 g8 [fis] e4 fis16 [g a8]
  b4 a8 [g] fis4\fermata \fine
}

bassMusic = {
  \voiceTwo
  \repeat volta 2 {
    \partial 4  d'8 [cis']
    b4 a8 [g] fis4 e
    d e a,\fermata b,
    cis d8 [e] fis4 g8 [fis]
    e [d] a,4 d\fermata }
  \partial 4  d8 [e]
  fis4 e8 [d] cis [d] e4
  a,2\fermata fis4 e8 [d]
  g4 a d\fermata fis
  b,8 cis d [e] a,4\fermata
  \partial 4 e8 [fis]
  g4 fis8 [e] dis4 e
  b,\fermata b, fis g
  d8 [cis] b,4 cis d
  g, a, d,\fermata \fine
}

versoOneLyrics = \lyricmode {\set stanza = 1
                             Ein' fe -- ste Burg ist un -- ser Gott, ein' gu -- te Wehr und Waf -- _ fen.
                             Der _ alt bö -- se Feind, mit Ernst er's jetzt meint,
                             groß Macht und viel List sein grau -- sam Rüst -- zeug ist,
                             auf Erd ist nicht seins -- Glei -- _ _ chen. }

versoTwoLyrics = \lyricmode {\set stanza = 2
                             er hilft uns frei aus al -- ler Not, die uns jetz hat be -- tro -- _ fen. }
