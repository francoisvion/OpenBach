 voiceone = \relative c'' {
 \override Staff.NoteCollision #'merge-differently-dotted = ##t
 \set harmonicDots = ##t
 \set fingeringOrientations = #'(left)
 \repeat volta 2 {
    %1-5
    \stemDown < g'-1^\1 >4
    \once \override Slur #'control-points = #'((1.0 . 3.5) (2 . 4.5) (5 . 4.5) (6 . 4.0))
    g4 ( a8.\mordent) b16 a8
    \stemUp \slurDown \SInd \appoggiatura g16 \stemDown fis8
    \stemUp \slurDown \SInc \appoggiatura e16  d2
    \stemUp < g,-2_\2 >4\mordent g4.\downprall fis16 g16
    a32[( g32 fis16) g32( fis32 e16_\3)]
    \once \override Fingering.font-size = #-5
    \grace < e-0 >8 d2\harmonic_\4
    \stemDown < d'-1^\1 >4 \slurUp d4( e8.\mordent) f16

        %6-10
    e8
   \once \override Slur #'control-points = #'((.5 . .4) (1.0 . -0.8) (1.4 . -0.3) (1.8 . -.5))
   \stemUp \slurDown \appoggiatura d16 \stemDown c8
    \once \override Slur #'control-points = #'((.5 . -0.7) (.8 . -1.0) (1.4 . -1.6) (2.2 . -1.3))
    \stemUp \slurDown \appoggiatura b16 \stemUp a4._\4\harmonic \stemDown < fis'-3 >8\turn
    \slurUp
    \stemDown \SDne g32[( fis16.) a32( g16.)] fis32[( e16.) d32( < c-1 >16.)]
    \once \override Slur #'control-points = #'((.5 . 3.0) (0.6 . 4.0) (1.8 . 4.5) (2.4 . 3.9))
    \stemUp \appoggiatura c8 \stemDown a'8. < c,-2 >16
    \stemUp \slurDown
    \SUpf b32\harmonic[( g16.)\harmonic < fis-1_\2 >8] \appoggiatura fis8 g2\mordent
    \stemNeutral < b-1^\1 >4 b4^( cis8.\mordent) d16
    \stemUp
    d16 cis16 b16 \H a16^\4 d2\harmonic^\3 

        %11-15
    \stemNeutral \tieNeutral
    \set fingeringOrientations = #'(right)
    < b e g-1 >4\arpeggio
    \set fingeringOrientations = #'(left)
    \clef "G_8" < g-2 >4.\downprall fis16 g16
    g8 \stemUp \SIne \appoggiatura fis16 \stemDown e8^\2
    \set fingeringOrientations = #'(right)
    < cis-1 >4.\lineprall
    \set fingeringOrientations = #'(left)
    < e-0 >8
    \slurNeutral
    < a-4 >16( g16 fis16 e16) < d-2 >8 \stemUp < a-1 >4^~ \stemNeutral a32 b32 c16
    b16( a16 g16 fis16) < e-1 >8 \stemUp \grace d'16 \stemDown cis4~ cis32 d32 e16
    d16( cis16 b16 a16) < g'-2 >8 < b,-0 >4 cis8

        %16
   \stemUp \grace cis16 \stemDown \TUpv d8 ~ [ d32 e32 d32 cis32 ] \stemUp \grace cis8 \stemDown d2 
 }

    \repeat volta 2 {
    \stemNeutral
    \set fingeringOrientations = #'(left)
    < a-1_\3 >4\mordent a4_~\downprall a16[ a32( b32 c32
    \set fingeringOrientations = #'(right)
    \once \override Fingering.extra-offset = #'(-1.4 . -1.2)
    < d-3 >32
    \once \override Fingering.extra-offset = #'(-1.4 . -1.2)
    < e-3 >16)]
    \set fingeringOrientations = #'(left)
    \stemUp \grace e16 \stemDown d8
    \stemUp \slurDown \SInb \appoggiatura c16 \stemDown b8_\3
    \stemUp \slurDown \SUpe \appoggiatura a8 \stemNeutral g4. < g'-4^\2 >8
    \stemUp \slurDown \SIna
    \once \override Fingering.font-size = #-5
    \appoggiatura < fis-4 >16 \stemDown
    \set fingeringOrientations = #'(right)
    \once \override Fingering.extra-offset = #'(-1.8 . -1.3)
    e8.
    \set fingeringOrientations = #'(left)
    fis32 dis32
    \stemUp \slurDown \SInf \appoggiatura dis8 \stemDown  e4.\mordent < a-1 >32 b32 a32 g32
    a8. < fis-4 >16
    \stemUp \slurDown \SUpa \appoggiatura e16 \stemDown dis4. < b-0 >8

        %21-25
    \set fingeringOrientations = #'(right)
    \grace{\graceSchleifer e16}
    \once \override Fingering.extra-offset = #'(-1.7 . -1.0)
    < g-2^\1 >8. fis16
    \stemUp \slurDown \grace fis8 \stemDown \TUpo < e-0 >4^~ e16[
    \set fingeringOrientations = #'(left)
    < b-3_\3 >16 c32^( b32 a32 b32)]
    \set fingeringOrientations = #'(right)
    g'32[^( e16.) \SDnd fis32^( < dis-3 >16.)]
    \stemUp \grace dis8 \stemDown \TUpo < e-4 >4^~ \stemNeutral e16
    \set fingeringOrientations = #'(left)
    g,16 fis16 e16
    < fis-2 >8. < e'-4 >16 \stemUp \grace e16 \stemDown
    \set fingeringOrientations = #'(right)
    < dis-3 >8 \grace{\GraceSchleifer e16}
    a8 g8 fis8
    \set fingeringOrientations = #'(left)
    \stemUp
    \once \override Fingering.font-size = #-5
    \grace fis16 \stemDown
    \override Fingering.staff-padding = #'()
    \set fingeringOrientations = #'(down)
    \stemUp e8. fis32 dis32 \grace dis8  
    \set fingeringOrientations = #'(right)
    < e\harmonic^\5^\1-0 >2

    \clef treble

    \set fingeringOrientations = #'(left)
    \stemDown < e'-3^\1 >8
    \once \override Slur #'control-points = #'((.5 . .4) (.8 . -0.2) (1.2 . -0.5) (1.8 . -0.3))
    \stemUp \slurDown \appoggiatura d16 \stemDown c8
    \once \override Slur #'control-points = #'((.5 . -0.6) (.8 . -1.1) (1.2 . -1.3) (1.6 . -1.2))
    \SOuta \stemUp \slurDown \appoggiatura b16

    \stemNeutral \slurNeutral

    a4. b16 c16]

       %26-30
    d32[( c32 b16) c32( b32 a16)] \grace a8 \stemUp g4._\3 < a-1_\2 >16 b16
       %27-28
    c16 d16 c16 b16
    \once \override Beam.positions = #'(3.4 . 3.0)
    c16 < a-2 >16 e16 a16
    \set fingeringOrientations = #'(right)
    < c-4 >4^~ | c16 d16 c16 b16 c16 a16 fis16 a16 c16 e16 d16 c16 
    %29-30
    \textSpannerUp
    \override TextSpanner #'(bound-details left text) = #"XII "
    b16 \startTextSpan
    c16 b16 a16 b16 g16 d16 g16 b16 g16 c16 d16 |
    e16 f16 e16 d16 e16 c16 g16 c16 e16 c16 fis16 g16
        %31-32
    \stemNeutral
    \set fingeringOrientations = #'(left)
    a16 < c,_2_\2 >16 b16 a16 b16 c16 d16 < g,_1_\3 >16 b16 a16 \stopTextSpan g16 fis16
    \TInb  g4^\3^\harmonic^~ g16\harmonic d16^\4\harmonic g16\harmonic
    fis16^\1_1 \slurDown \appoggiatura fis8 \slurDown g4 
   }
}

 voicetwo = \relative c' {
    \set fingeringOrientations = #'(left)
    \repeat unfold 9 { s2. }
    e8.\rest \stemDown \H a16_~ a2\harmonic
    \repeat unfold 13 { s2. }
    e,2\rest \stemDown \extendLV #3.0 e4_\6\harmonic \laissezVibrer 
    \hideNotes 
    s4 a4 a16 a a a |
    \unHideNotes 

    s2. |
    d4.\rest < e-1_\3 >4. | < fis-2 >4. fis4. |
    \once \override Fingering.extra-offset = #'(-0.0 . 0.4)
    < g-1 >8. r8. d8._\4 \TUpb g8.~_\3 | g4. g8. c8. | s2. |
    c,16\rest < c-4_\5 >16 b16 a16
    \set fingeringOrientations = #'(right)
    \once \override Fingering.extra-offset = #'(-1.0 . -1.0)
     < b-0_\5 >2 |
}

 guitarone = << \voiceone \\ \voicetwo >>

