\version "2.18.2"

\include "v10/guitar1.ly"
\include "v10/guitar2.ly"
\include "v10/guitar3.ly"
\include "v10/guitar4.ly"

global = {
  \time 2/2
  \key g \major
  \clef "G_8"
}

\bookpart {

    \paper {
	page-count = #2
	system-count = #8

	bottom-margin = 2 \mm

        top-system-spacing =
                #'((basic-distance . 10)
                   (minimum-distance . 6)
                   (padding . 0))
%                   (stretchability . 4))

	system-system-spacing =
	    #'((basic-distance . 20)
	       (minimum-distance . 12)
	       (padding . 4)
	       (stretchability . 12))
    }

    \header {
	title = "Variation 10"
	subtitle = " "
%	subsubtitle = " "

	meter = \markup {
		\translate #`( 0 . 2 ) { \hspace #4 \roman \fontsize #1.0 "Fughetta" }
	   }

	copyright = \markup {
			 \fill-line {
			     \tiny {
				\line {Steve Shorter (2014). Hajo Delzelski (2008). \epsfile #X #10 #'"/by-sa.eps" }
			     }
		        }
		}
    }

   \tocItem \markup { "Variation 10" \hspace #10 "Fughetta" }

  \score {
    \new GrandStaff \with {
            \override StaffGrouper.staff-staff-spacing =
                #'((basic-distance . 12)
                   (minimum-distance . 8)
                   (padding . 0))
	}
    <<
	\set GrandStaff.instrumentName =
		\markup {
			\override #'(font-family . "Sans")
			\abs-fontsize #12.0 \bold "Guitar  " 
		}

	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitarone >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitartwo >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitarthree >>
	\new Staff \with { \consists "Span_arpeggio_engraver" }
                   << \global \guitarfour >>
    >>

    \layout {
        \context {
           \Score
%             \override NonMusicalPaperColumn #'line-break-permission = ##f
%            \override NonMusicalPaperColumn #'page-break-permission = ##f
       }
    }
  }
}

